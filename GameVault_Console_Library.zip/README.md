# GameVault — Console Game Library

A phone-friendly, console-style personal game library.

## Included
- Your supplied starter game list
- Physical disc / digital ownership
- Like / dislike
- Wishlist
- Completion status
- PS5 / Xbox / PC / Switch platform fields
- Genres and release years
- A–Z, release-year and rating sorting
- Search and filters
- Console-style cover grid and featured game
- Game descriptions, cover URLs and screenshot URL fields
- JSON backup/export and import
- Local browser storage
- Optional automatic metadata and cover lookup through RAWG

## Automatic lookup
Open **Settings / Metadata** and paste a RAWG API key. The app will then let you look up an individual game or fill missing metadata across the library.

Without an API key, the library still works normally and you can enter metadata and cover URLs yourself.

## Use
Open `index.html` in a modern browser. On Android Chrome, you can use the browser menu and choose **Add to Home screen** when hosted from a normal web server.

## Backup
Use **Export Backup** regularly. The exported JSON can be restored with **Import Backup**.
